                         Application Note 3684 - Version 2.0

Introduction
------------

The following C code example demonstrates how to create a application programmer interface
for the DS2482 I2c to 1-Wire bridge. 


Files
-----
  Board 
       DS2482toMAXQ1.PDF - Schematic and layout of daughter board for the DS2482-100 
                           or DS2482-101 on the CMAXQUSB evaluation kit platform. 

  FTDIDriver - CMAXQUSB device driver. 

  Legacy
       an3684.zip - Previous version of example code for AN3684 using the Keil uVision2 compiler


  Source 
    AN3684.C - 'C' module to demonstrate code from AN3684. Communicates directly to I2C routines
               from the CMAXQUSB.
    AN3684.sln, AN3684.suo, AN3684.vcproj - Project files for Visual Studio
    
    Release
        AN3648.EXE - Executable of AN3684 demo
        CMODCOMM.DLL - Communication module for CMAXQUSB
               


