03/27/03

Test implementation for the 'C' code example in 
Application Note 192 "Using the DS2480B Serial 1-Wire Line Driver".

This implementation uses the Windows 32-bit serial 
communication API and a standard DS9097U serial adapter
initializing the DS2480B.

For other 1-Wire software see the 'Software Developer's Tools'
on iButton:  http://www.ibutton.com/


