                          1-Wire Public Domain Kit

                        USerial Build for Win32 w/VC
                            Version 3.1 3/24/06

Introduction
------------

   This port was targeted for the Windows 32-bit platform and tested on a
   Windows ME.  The provided workspace will build all of the example
   programs distributed int the 3.00 1-Wire Public Domain release.

   The new link file for the USerial Build for Win32 build is:

      win32lnk.c

Examples
--------
   atod
   counter
   coupler
   debit
   fish
   gethumd
   humalog
   initcopr
   initrov
   memutil
   mweather
   ps_check
   ps_init
   sha_chck
   sha_init
   shaapp
   swtloop
   swtsngl
   temp
   thermodl
   thermoms
   tm_check
   tm_init
   tstfind

Tool Versions
-------------

   Microsoft Visual C++ 6.0 Standard Edition was used in
   building the applications executables.

General Notes
-------------

   - Relevant 1-Wire Information:
     http://www.ibutton.com
     http://www.maxim-ic.com/

   - 1-Wire Mailing List:
     http://lists.dalsemi.com/mailman/listinfo/1-wire-software-development

